/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.primerproyectomaven;
import javax.swing.*;
import java.util.Arrays;
/**
 *
 * @author Administrador
 */

public class PrimerProyectoMaven {

public static void main(String[] args) {
        // Definimos el array
        int[] array = {10, 20, 30, 40, 50};
        
        // Mostramos el contenido del array
        JOptionPane.showMessageDialog(null, "Contenido del array: " + Arrays.toString(array));
        
        // Solicitamos al usuario un número para buscar
        String input = JOptionPane.showInputDialog("Ingresa un número para buscar en el array:");
        
        // Validamos la entrada y convertimos a entero
        try {
            int numeroBuscado = Integer.parseInt(input);
            boolean encontrado = false;
            
            // Buscamos el número en el array
            for (int num : array) {
                if (num == numeroBuscado) {
                    encontrado = true;
                    break;
                }
            }
            
            // Mostramos el resultado
            if (encontrado) {
                JOptionPane.showMessageDialog(null, "El número " + numeroBuscado + " está presente en el array.");
            } else {
                JOptionPane.showMessageDialog(null, "El número " + numeroBuscado + " NO está presente en el array.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, ingresa un número válido.");
        }
    }
    
}
